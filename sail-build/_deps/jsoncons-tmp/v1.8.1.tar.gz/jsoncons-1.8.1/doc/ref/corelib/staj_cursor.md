### jsoncons::staj_cursor

```cpp
#include <jsoncons/staj_cursor.hpp>

typedef basic_staj_cursor<char> staj_cursor
```

The `staj_cursor` interface supports forward, read-only, access to JSON and JSON-like data formats.

The `staj_cursor` is designed to iterate over stream events until `done()` returns **true**.
The `next()` function causes the reader to advance to the next stream event. The `current()` function
returns the current stream event. The data can be accessed using the [staj_event](basic_staj_event.md) 
interface. When `next()` is called, copies of data previously accessed may be invalidated.

#### Destructor

    virtual ~basic_staj_cursor() noexcept = default;

#### Member functions

##### staj_event input

    virtual bool done() const = 0;
Check if there are no more events.

    virtual void next() = 0;
Get the next event. If a parsing error is encountered, throws a [ser_error](ser_error.md).

    virtual void next(std::error_code& ec) = 0;
Get the next event. If a parsing error is encountered, sets `ec`.

    virtual const staj_event& current() const = 0;
Returns the current [staj_event](basic_staj_event.md).

    virtual const ser_context& context() const = 0;
Returns the current [context](ser_context.md)

    virtual void read_to(json_visitor& visitor) = 0;
Sends the parse events from the current event to the
matching completion event to the supplied [visitor](basic_json_visitor.md)
E.g., if the current event is `begin_object`, sends the `begin_object`
event and all inbetween events until the matching `end_object` event.
If a parsing error is encountered, throws a [ser_error](ser_error.md).

    virtual void read_to(json_visitor& visitor, std::error_code& ec) = 0;
Sends the parse events from the current event to the
matching completion event to the supplied [visitor](basic_json_visitor.md)
E.g., if the current event is `begin_object`, sends the `begin_object`
event and all inbetween events until the matching `end_object` event.
If a parsing error is encountered, sets `ec`.

##### Typed array input

    virtual bool is_typed_array() const;                         (since 1.8.0)

    virtual typed_array_tags array_tag() const;                  (since 1.8.0)
Returns a [tag](typed_array_tags.md) that indicates the element type of the typed array.

    virtual jsoncons::span<uint8_t> array_buffer();              (since 1.8.0)

    virtual void to_end_array();                                 (since 1.8.0)

    template <typename T>                                        (since 1.8.0)
    void read_typed_array(T& v);

##### Multi-dimensional array input

    virtual bool is_multi_dim() const;                           (since 1.8.0)
Indicates whether an array is a multi-dimensional array.

    virtual jsoncons::span<const std::size_t> extents() const;   (since 1.8.0)
Indicates the number of elements along each dimension of the array.

    virtual mdarray_order order() const;                         (since 1.8.0)
Indicates whether the elements of a multi-dimensional array are
arranged in row-major or column-major order. Returns a [mdarray_order](mdarray_order.md).


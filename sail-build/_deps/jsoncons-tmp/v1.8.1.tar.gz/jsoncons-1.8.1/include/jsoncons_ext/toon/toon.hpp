// Copyright 2013-2026 Daniel Parker
// Distributed under the Boost license, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

// See https://github.com/danielaparker/jsoncons for latest version

#ifndef JSONCONS_TOON_TOON_HPP 
#define JSONCONS_TOON_TOON_HPP 

#include <jsoncons_ext/toon/encode_toon.hpp>

#endif // JSONCONS_TOON_TOON_HPP 

